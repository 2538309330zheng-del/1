console.log("[figmaEX] extension content.js (01)");

function injectScript(file_path, tag) {
  var node = tag
    ? document.getElementsByTagName(tag)[0]
    : document.documentElement;
  var script = document.createElement("script");
  script.setAttribute("type", "text/javascript");
  script.setAttribute("src", file_path);
  node.appendChild(script);
}

// injectScript(chrome.runtime.getURL("init.js"))

document.addEventListener(
  "DOMContentLoaded",
  function () {
    injectScript(chrome.runtime.getURL("app.js"), "body");
  },
  false
);

